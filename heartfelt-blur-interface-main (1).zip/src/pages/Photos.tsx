
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XIcon } from 'lucide-react';
import Dashboard from '@/components/Dashboard';

const Photos = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  // You'll need to replace these with actual photos
  const photos = [
    {
      id: 1,
      src: "https://i.ibb.co/BVpD0Fr4/IMG-20250128-WA0068.jpg",
      alt: "Você tava tão linda nessa foto",
    },
    {
      id: 2,
      src: "https://i.ibb.co/mCVZNz0D/IMG-20250128-WA0070.jpg",
      alt: "Facilmente essa fica na lista das 3 que eu mais gosto",
    },
    {
      id: 3,
      src: "https://i.ibb.co/1JJFz7Kg/IMG-20250128-WA0071.jpg",
      alt: "Esplêndida",
    },
    {
      id: 4,
      src: "https://i.ibb.co/MxWVFNpt/IMG-20250128-WA0069.jpg",
      alt: "Você tava tão maravilhosa nessa foto",
    },
    {
      id: 5,
      src: "https://i.ibb.co/mVyLWcjL/IMG-20250124-WA0034.jpg",
      alt: "Mesmo com ciúmes eu gostava tanto dos seus gatoskkk",
    },
    {
      id: 6,
      src: "https://i.ibb.co/mVvKNNG2/IMG-20250110-WA0783.jpg",
      alt: "Amo tanto esses olinhos, eu via o nosso futuro neles, mas acho que era só o reflexo do meu",
    },
  ];
  
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen py-8 px-4 container max-w-5xl mx-auto"
    >
      <header className="mb-8">
        <Dashboard />
      </header>
      
      <main>
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-3xl md:text-4xl font-playfair text-center mb-8 text-gradient"
        >
          Galeria de Fotos
        </motion.h1>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, index) => (
            <motion.div 
              key={photo.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1, duration: 0.5 }}
              className="glass-card rounded-xl overflow-hidden cursor-pointer transform transition-transform hover:scale-105 hover:shadow-lg"
              onClick={() => setSelectedImage(photo.src)}
            >
              <div className="aspect-[4/5] relative">
                <img 
                  src={photo.src} 
                  alt={photo.alt} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end">
                  <p className="text-white p-4 font-medium">{photo.alt}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </main>
      
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div 
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              transition={{ duration: 0.3 }}
              className="relative max-w-4xl max-h-[90vh]"
            >
              <button 
                className="absolute top-4 right-4 z-10 p-2 bg-black/50 rounded-full text-white hover:bg-black/70 transition-colors"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedImage(null);
                }}
              >
                <XIcon size={20} />
              </button>
              <img 
                src={selectedImage} 
                alt="Foto ampliada" 
                className="max-w-full max-h-[90vh] object-contain rounded-lg"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <footer className="mt-16 text-center text-sm text-doki-dark/60">
        <p>Feito com choros e lembranças</p>
      </footer>
    </motion.div>
  );
};

export default Photos;

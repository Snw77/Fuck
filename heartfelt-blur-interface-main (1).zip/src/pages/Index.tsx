
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Welcome from '@/components/Welcome';
import Dashboard from '@/components/Dashboard';
import Profile from '@/components/Profile';
import MessageCarousel from '@/components/MessageCarousel';
import SecondChance from '@/components/SecondChance';

const Index = () => {
  const [showWelcome, setShowWelcome] = useState(true);
  
  // Messages to display in the carousel
  const messages = [
    "Você me mostrou o paraiso, mas eu fui la e me joguei ao inferno.",
    "Esse ano começou tão bem, mais nem terminou e já estou destruído.",
    "A sensação de ver você indo embora foi tão ruim, que eu morri naquele dia.",
    "Fazer esse site foi dolorido, pois cada lagrima de tristeza estava cheia de felicidade, pois me lembra cada momento feliz nosso.",
    "Se a depressão vencer, saiba que você foi o motivo de eu ter continuado mais um pouco",
    "Minha mente já aceitou que você não vai voltar, mas meu coração ainda tenta.",
  ];
  
  // Description about her - you'll need to customize this
  const description = "Nicolle, quando eu te conheci na house, meu coração acelerou, mas depois que começamos a conversar, eu percebi que era amor, você me contou traumas e segredos que ninguém sabia, eu te mostrei e contei coisas da minha vida que ninguém tinha, você me fazia feliz, e ainda faz, e como um obrigado e minha última declaração de amor, fiz esse site chorando, pois saber que infelizmente não vou te esquecer e vou ver você namorar, casar e ter uma família com outro, dói, mas eu só quero que você seja feliz, tbom minha princesinha?";
  
  // Placeholder URL - you'll need to replace this with the actual image
  const imageUrl = "https://i.ibb.co/BVpD0Fr4/IMG-20250128-WA0068.jpg";
  
  // Name - you'll need to customize this
  const name = "Nicolle";

  return (
    <>
      {showWelcome && <Welcome onComplete={() => setShowWelcome(false)} />}
      
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="min-h-screen py-8 px-4 container max-w-5xl mx-auto"
      >
        <header className="mb-8">
          <Dashboard />
        </header>
        
        <main>
          <MessageCarousel messages={messages} />
          
          <Profile 
            name={name}
            image={imageUrl}
            description={description}
          />
          
          <div className="flex justify-center mt-12">
            <SecondChance />
          </div>
        </main>
        
        <footer className="mt-16 text-center text-sm text-doki-dark/60">
          <p>Feito com choros e lembranças de SnooW</p>
        </footer>
      </motion.div>
    </>
  );
};

export default Index;


import { motion } from 'framer-motion';
import Dashboard from '@/components/Dashboard';
import LiveStream from '@/components/LiveStream';

const Lives = () => {
  // You'll need to replace this with the actual channel ID
  const channelId = 'oM6n3KrPzFfBeuCR'; // This is just an example channel ID
  
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen py-8 px-4 container max-w-5xl mx-auto"
    >
      <header className="mb-8">
        <Dashboard />
      </header>
      
      <main>
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-3xl md:text-4xl font-playfair text-center mb-8 text-gradient"
        >
          Transmissões ao Vivo
        </motion.h1>
        
        <LiveStream channelId={channelId} />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="glass-card rounded-xl p-6 mt-8"
        >
          <h2 className="text-xl font-playfair mb-4 text-gradient">Sobre as Lives</h2>
          <p className="text-foreground">
            Aqui você pode assistir às transmissões ao vivo do Kleberiano diretamente neste site. 
            Quando uma nova transmissão começar, ela aparecerá automaticamente aqui para você assistir 
            na melhor qualidade. Se não houver transmissão no momento, você pode visitar o canal 
            para ver vídeos anteriores.
          </p>
        </motion.div>
      </main>
      
      <footer className="mt-16 text-center text-sm text-doki-dark/60">
        <p>Feito com choros e lembranças</p>
      </footer>
    </motion.div>
  );
};

export default Lives;

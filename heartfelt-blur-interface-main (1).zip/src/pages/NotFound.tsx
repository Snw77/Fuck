
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { motion } from 'framer-motion';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex items-center justify-center p-4"
    >
      <div className="glass-card rounded-xl p-8 text-center max-w-md">
        <h1 className="text-6xl font-playfair text-gradient mb-4">404</h1>
        <p className="text-xl text-foreground mb-6">Oops! Página não encontrada</p>
        <Link 
          to="/" 
          className="glass-button border-doki-pink hover:bg-doki-pink/20 transition-all pink-glow inline-block"
        >
          Voltar ao Início
        </Link>
      </div>
    </motion.div>
  );
};

export default NotFound;

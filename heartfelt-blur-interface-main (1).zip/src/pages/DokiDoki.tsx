
import { motion } from 'framer-motion';
import Dashboard from '@/components/Dashboard';

const DokiDoki = () => {
  // You'll need to replace these with actual videos
  const videos = [
    {
      id: 1,
      title: "Doki Doki Literature Club - Episódio 1",
      thumbnail: "https://i.ytimg.com/vi/placeholder1/maxresdefault.jpg",
      videoId: "45b7qEt18as", // Replace with actual YouTube video ID
      description: "Kleberiano joga Doki Doki Literature Club pela primeira vez!",
    },
    {
      id: 2,
      title: "Doki Doki Literature Club - Episódio 2",
      thumbnail: "https://i.ytimg.com/vi/placeholder2/maxresdefault.jpg",
      videoId: "GFDOQnSeSjI", // Replace with actual YouTube video ID
      description: "A aventura continua no clube de literatura!",
    },
    {
      id: 3,
      title: "Doki Doki Literature Club - Episódio 3",
      thumbnail: "https://i.ytimg.com/vi/placeholder3/maxresdefault.jpg",
      videoId: "FUh9akr_tro", // Replace with actual YouTube video ID
      description: "As coisas começam a ficar estranhas...",
    },
    {
      id: 4,
      title: "Doki Doki Literature Club - Episódio 4",
      thumbnail: "https://i.ytimg.com/vi/placeholder4/maxresdefault.jpg",
      videoId: "mw48-SsytVA", // Replace with actual YouTube video ID
      description: "Revelações surpreendentes!",
    },
  ];
  
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen py-8 px-4 container max-w-5xl mx-auto"
    >
      <header className="mb-8">
        <Dashboard />
      </header>
      
      <main>
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-3xl md:text-4xl font-playfair text-center mb-8 text-gradient"
        >
          Doki Doki Literature Club
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="glass-card rounded-xl p-6 mb-8"
        >
          <p className="text-foreground">
            Confira todos os vídeos e lives de Doki Doki Literature Club do Kleberiano! 
            Clique em qualquer vídeo abaixo para assistir diretamente aqui no site.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {videos.map((video, index) => (
            <motion.div 
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1, duration: 0.5 }}
              className="glass-card rounded-xl overflow-hidden"
            >
              <div className="aspect-video relative bg-doki-pink/20">
                <a 
                  href={`https://www.youtube.com/watch?v=${video.videoId}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="absolute inset-0 flex items-center justify-center group"
                >
                  <div className="w-16 h-16 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center transition-transform group-hover:scale-110">
                    <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[16px] border-l-doki-dark border-b-[8px] border-b-transparent ml-1"></div>
                  </div>
                </a>
              </div>
              <div className="p-4">
                <h3 className="font-playfair text-lg font-medium text-doki-dark mb-2">{video.title}</h3>
                <p className="text-sm text-foreground/80">{video.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </main>
      
      <footer className="mt-16 text-center text-sm text-doki-dark/60">
        <p>Feito por choros e lembranças</p>
      </footer>
    </motion.div>
  );
};

export default DokiDoki;


import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface LiveStreamProps {
  channelId: string;
}

const LiveStream = ({ channelId }: LiveStreamProps) => {
  const [isLive, setIsLive] = useState(false);
  const [videoId, setVideoId] = useState('');
  const [loading, setLoading] = useState(true);

  // This is a mock implementation - in a real app you would use the YouTube API
  useEffect(() => {
    // Simulate checking if channel is live
    const checkLiveStatus = () => {
      // Simulate API call
      setLoading(true);
      setTimeout(() => {
        // For demo purposes, we'll randomly decide if the stream is live or not
        // In a real implementation, you would use the YouTube API to check this
        const mockIsLive = Math.random() > 0.5;
        setIsLive(mockIsLive);
        
        if (mockIsLive) {
          // Mock video ID - in a real app, you would get this from the API
          setVideoId('dQw4w9WgXcQ'); // This is just a placeholder YouTube video ID
        }
        
        setLoading(false);
      }, 1500);
    };

    checkLiveStatus();
    
    // Check live status every 5 minutes
    const interval = setInterval(checkLiveStatus, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [channelId]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-card rounded-xl overflow-hidden p-6"
    >
      <h2 className="text-2xl font-playfair mb-4 text-gradient">Transmissão ao Vivo</h2>
      
      {loading ? (
        <div className="flex flex-col items-center justify-center py-16">
          <div className="w-12 h-12 rounded-full border-4 border-doki-pink border-t-transparent animate-spin mb-4"></div>
          <p className="text-foreground">Verificando transmissão...</p>
        </div>
      ) : isLive ? (
        <div className="aspect-video rounded-lg overflow-hidden">
          <iframe 
            width="100%" 
            height="100%" 
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=0`}
            title="YouTube livestream" 
            frameBorder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowFullScreen
            className="w-full h-full"
          ></iframe>
        </div>
      ) : (
        <div className="bg-doki-light/50 rounded-lg p-8 text-center">
          <h3 className="text-xl font-medium text-doki-dark mb-2">Não está ao vivo no momento</h3>
          <p className="text-doki-dark/70">
            Kleberiano não está transmitindo agora. Volte mais tarde!
          </p>
          <a 
            href={`https://www.youtube.com/channel/${channelId}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="glass-button inline-block mt-4"
          >
            Visitar Canal
          </a>
        </div>
      )}
    </motion.div>
  );
};

export default LiveStream;


import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface WelcomeProps {
  onComplete: () => void;
}

const Welcome = ({ onComplete }: WelcomeProps) => {
  const [visible, setVisible] = useState(true);
  
  const handleClick = () => {
    setVisible(false);
    setTimeout(() => {
      onComplete();
    }, 1000);
  };

  return visible ? (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
      className="fixed inset-0 flex items-center justify-center bg-doki-dark/40 backdrop-blur-lg z-50"
      onClick={handleClick}
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className="glass-card max-w-3xl mx-4 p-8 rounded-xl"
      >
        <h2 className="text-2xl md:text-3xl font-playfair mb-6 text-center text-gradient">
          Por eu saber que não tem volta, minha última tentativa de reconquistar você 
          é fazendo oque sei fazer de melhor, que é programar e te amar
        </h2>
        <p className="text-center text-sm text-doki-dark/70 mt-6 animate-pulse">
          Clique em qualquer lugar para continuar...
        </p>
      </motion.div>
    </motion.div>
  ) : null;
};

export default Welcome;

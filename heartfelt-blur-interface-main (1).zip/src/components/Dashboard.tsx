
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { TvIcon, ImageIcon, HeartIcon, HomeIcon } from 'lucide-react';

const Dashboard = () => {
  const location = useLocation();
  const [hovered, setHovered] = useState<string | null>(null);
  
  const items = [
    { icon: HomeIcon, label: 'Início', path: '/' },
    { icon: TvIcon, label: 'Lives', path: '/lives' },
    { icon: ImageIcon, label: 'Fotos', path: '/photos' },
    { icon: HeartIcon, label: 'Doki Doki', path: '/doki-doki' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-card rounded-full py-2 px-4 flex items-center justify-center space-x-1 md:space-x-2 max-w-md mx-auto shadow-lg"
    >
      {items.map((item, index) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;
        
        return (
          <Link 
            key={index}
            to={item.path}
            className="relative"
            onMouseEnter={() => setHovered(item.label)}
            onMouseLeave={() => setHovered(null)}
          >
            <motion.div
              className={`p-2 md:p-3 rounded-full transition-all duration-300 flex flex-col items-center ${
                isActive 
                  ? 'bg-doki-pink text-white pink-glow'
                  : 'text-foreground hover:bg-doki-light'
              }`}
            >
              <Icon size={18} />
              <span className="text-xs mt-1 font-medium hidden md:inline">{item.label}</span>
            </motion.div>
            
            {hovered === item.label && !isActive && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-white/90 backdrop-blur-sm py-1 px-2 rounded text-xs pointer-events-none z-10 whitespace-nowrap md:hidden"
              >
                {item.label}
              </motion.div>
            )}
          </Link>
        );
      })}
    </motion.div>
  );
};

export default Dashboard;


import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XIcon } from 'lucide-react';

const SecondChance = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="glass-button text-doki-dark border-doki-pink hover:bg-doki-pink/20 transition-all pink-glow"
      >
        Segunda Chance
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-md flex items-center justify-center z-50 p-4"
            onClick={() => setIsOpen(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="glass-card max-w-2xl p-8 rounded-xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={() => setIsOpen(false)}
                className="absolute top-3 right-3 p-1 rounded-full bg-white/50 hover:bg-white/80 transition-colors"
              >
                <XIcon size={20} className="text-doki-dark" />
              </button>
              
              <h2 className="text-2xl font-playfair mb-6 text-center text-gradient">
                Mensagem Especial
              </h2>
              
              <p className="text-foreground leading-relaxed text-center">
                "Não precisa dar uma segunda chance, você sempre será minha princesinha, 
                eu irei chorar todos os dias de felicidade vendo nossas conversas, 
                eu sei que fiz o amor que você tinha por mim sumir, mas não quero 
                forçar criar um amor que você não sente mais."
              </p>
              
              <div className="flex justify-center mt-8">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="glass-button"
                >
                  Fechar
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default SecondChance;

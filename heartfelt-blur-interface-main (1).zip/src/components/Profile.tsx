
import { motion } from 'framer-motion';

interface ProfileProps {
  name: string;
  image: string;
  description: string;
}

const Profile = ({ name, image, description }: ProfileProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4, duration: 0.8 }}
      className="glass-card rounded-xl overflow-hidden max-w-md mx-auto my-8"
    >
      <div className="relative w-full h-60 overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <h2 className="absolute bottom-4 left-4 text-white text-3xl font-playfair">{name}</h2>
      </div>
      <div className="p-6">
        <p className="text-foreground leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
};

export default Profile;


import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface MessageCarouselProps {
  messages: string[];
}

const MessageCarousel = ({ messages }: MessageCarouselProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div className="w-full overflow-hidden py-4 bg-gradient-to-r from-doki-light via-white to-doki-light border-y border-doki-pink/30 my-8">
      <div className="relative flex" ref={containerRef}>
        <div className="flex whitespace-nowrap animate-scroll-text">
          {messages.map((message, index) => (
            <div 
              key={index} 
              className="mx-8 text-doki-dark font-medium"
            >
              ❤️ {message}
            </div>
          ))}
        </div>
        <div className="flex whitespace-nowrap animate-scroll-text" style={{marginLeft: '10px'}}>
          {messages.map((message, index) => (
            <div 
              key={index} 
              className="mx-8 text-doki-dark font-medium"
            >
              ❤️ {message}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MessageCarousel;
